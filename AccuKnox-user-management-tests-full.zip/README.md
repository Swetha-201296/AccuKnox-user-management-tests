# AccuKnox-user-management-tests

## Project Setup

1. Install Python 3.7+ and pip
2. Install Playwright and dependencies:
```bash
pip install -r requirements.txt
playwright install
```
3. Run tests with pytest:
```bash
pytest
```

## Playwright Version
Tested with Playwright version: 1.35.0 (or latest)

## Project Structure
- `tests/page_objects/`: Page Object Model classes
- `tests/test_user_management.py`: Test cases using pytest
- `AccuKnox-Test-Cases.xlsx`: Manual test case document
