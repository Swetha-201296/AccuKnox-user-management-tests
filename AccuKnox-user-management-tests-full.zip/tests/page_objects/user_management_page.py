
from playwright.sync_api import Page

class UserManagementPage:
    def __init__(self, page: Page):
        self.page = page
        self.system_users_header = page.locator('h6:has-text("System Users")')
        self.add_user_button = page.locator('button:has-text("Add")')

    def wait_for_page_load(self):
        self.system_users_header.wait_for(state='visible', timeout=10000)

    def click_add_user(self):
        self.add_user_button.click()
        self.page.wait_for_selector('text=Add User', timeout=5000)
