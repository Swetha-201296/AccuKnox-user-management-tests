
import pytest
from tests.page_objects.login_page import LoginPage
from tests.page_objects.user_management_page import UserManagementPage

@pytest.fixture(scope='function')
def setup(browser):
    page = browser.new_page()
    login_page = LoginPage(page)
    user_management_page = UserManagementPage(page)
    yield page, login_page, user_management_page
    page.close()

def test_login(setup):
    page, login_page, _ = setup
    page.goto('https://your-orangehrm-url.com/login')
    login_page.login('Admin', 'admin123')
    assert page.locator('text=Dashboard').is_visible()

def test_system_users_page_load(setup):
    page, _, user_management_page = setup
    page.goto('https://your-orangehrm-url.com/admin/viewSystemUsers')
    user_management_page.wait_for_page_load()
    assert user_management_page.system_users_header.is_visible()

def test_add_user_button(setup):
    page, _, user_management_page = setup
    page.goto('https://your-orangehrm-url.com/admin/viewSystemUsers')
    user_management_page.wait_for_page_load()
    user_management_page.click_add_user()
    assert page.locator('text=Add User').is_visible()
