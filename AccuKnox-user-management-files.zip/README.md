# AccuKnox-user-management-tests

This repository contains automated end-to-end test cases for the User Management module of the OrangeHRM application using Playwright in Python.

## Features

- Uses the Page Object Model (POM) for easy maintenance
- Separate test blocks for each test scenario
- Robust selectors and proper waits
- Manual test cases document included

## Setup Instructions

1. Install Python 3.7+ and pip
2. Install Playwright and dependencies:

   ```bash
   pip install playwright
   playwright install
   ```

3. Run tests:

   ```bash
   pytest
   ```

## Playwright Version

Tested with Playwright version: `1.35.0` (or latest at the time)
